import math
def sinconvert(angle):
    return math.sin(angle)
def cosconvert(angle):
    return math.cos(angle)