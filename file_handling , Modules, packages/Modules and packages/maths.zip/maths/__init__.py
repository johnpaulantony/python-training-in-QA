from maths.arth import addition,subtraction,multiply
from maths.tri import sinconvert